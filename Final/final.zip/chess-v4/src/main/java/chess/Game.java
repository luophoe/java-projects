package chess;

/**
 * boot
 */


public class Game {

	public static void main(String[] args) {
		View view = new View();
		view.create();
	}
}
